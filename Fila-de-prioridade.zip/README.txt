# Fila de prioridade
Foram realizadas todas atividades propostas!!
Dupla: Leandro Oliveira do Nascimento e Lucas Xavier Paire
